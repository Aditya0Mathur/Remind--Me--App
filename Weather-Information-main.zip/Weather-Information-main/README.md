# Weather-info-Project

Developed a full stack website that enables us to check weather of a location by entering its PIN CODE or Co-
ordinates or Name of the city.
